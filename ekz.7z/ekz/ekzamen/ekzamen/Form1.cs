﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ekzamen
{
    enum RowState
    {
        Existed,
        New,
        Modified,
        ModifiedNew,
        Delete
    }
    public partial class Form1 : Form
    {
        DataBase dataBase = new DataBase();
        SqlConnection connection;

        string tableName;


        public Form1()
        {
            InitializeComponent();

            label3.Visible = false;
            Patinets1.Visible = false;
            label4.Visible = false;
            textBox1.Visible = false;
            label5.Visible = false;
            textBox2.Visible = false;
            label6.Visible = false;
            textBox3.Visible = false;
            label7.Visible = false;
            textBox4.Visible = false;
            label8.Visible = false;
            textBox5.Visible = false;
            label9.Visible = false;
            textBox6.Visible = false;


            dataBase.OpenConnection();
            connection = dataBase.GetConnection();
        }

        private void getData(string tableName)
        {
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();
            string sqlExpression = $"SELECT * FROM {tableName}";
            SqlCommand command = new SqlCommand(sqlExpression, connection);

            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows) // если есть данные
            {
                int colCount = reader.FieldCount;
                for (int i = 0; i < colCount; i++)
                {
                    dataGridView1.Columns.Add(reader.GetName(i), reader.GetName(i));
                }

                int rowsCount = 0;
                while (reader.Read())
                {

                    dataGridView1.Rows.Add();
                    for (int i = 0; i < colCount; i++)
                    {
                        dataGridView1.Rows[rowsCount].Cells[i].Value = reader.GetValue(i);
                    }
                    rowsCount++;

                }

                reader.Close();
            }

        }

        private void findData(string tableName, string id)
        {

            string sqlExpression = $"SELECT * FROM {tableName} WHERE ID = {id}";
            SqlCommand command = new SqlCommand(sqlExpression, connection);

            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows) // если есть данные
            {
                while (reader.Read())
                {
                    if (tableName == button1.Text)
                    {
                        Patinets1.Text = reader.GetValue(0).ToString();
                        textBox1.Text = reader.GetValue(1).ToString();
                        textBox2.Text = reader.GetValue(2).ToString();
                        
                    }
                    else if (tableName == button2.Text)
                    {
                        Patinets1.Text = reader.GetValue(0).ToString();
                        textBox1.Text = reader.GetValue(1).ToString();
                        textBox2.Text = reader.GetValue(2).ToString();
                        textBox3.Text = reader.GetValue(3).ToString();
                        textBox4.Text = reader.GetValue(4).ToString();
                        textBox5.Text = reader.GetValue(5).ToString();
                        textBox6.Text = reader.GetValue(6).ToString();
                    }
                    else if (tableName == button3.Text)
                    {
                        Patinets1.Text = reader.GetValue(0).ToString();
                        textBox1.Text = reader.GetValue(1).ToString();
                        textBox2.Text = reader.GetValue(2).ToString();
                        textBox3.Text = reader.GetValue(3).ToString();
                        textBox4.Text = reader.GetValue(4).ToString();
                    }
                    else if (tableName == button4.Text)
                    {
                        Patinets1.Text = reader.GetValue(0).ToString();
                        textBox1.Text = reader.GetValue(1).ToString();
                        textBox2.Text = reader.GetValue(2).ToString();
                        
                    }
                    else if (tableName == button9.Text)
                    {
                        Patinets1.Text = reader.GetValue(0).ToString();
                        textBox1.Text = reader.GetValue(1).ToString();
                        textBox2.Text = reader.GetValue(2).ToString();
                        
                    }



                }

            }

            reader.Close();
        }

        private void updateData(string tableName)
        {
            string sqlExpression = "";
            if (tableName == button1.Text)
            {
               sqlExpression = $"UPDATE {tableName} SET {label4.Text}='{textBox1.Text}', {label5.Text}={textBox2.Text} WHERE ID={Patinets1.Text}";

            }
            else if (tableName == button2.Text)
            {
                sqlExpression = $"UPDATE {tableName} SET {label4.Text}='{textBox1.Text}', {label5.Text}='{textBox2.Text}', {label6.Text}='{textBox3.Text}', {label7.Text}='{textBox4.Text}', {label8.Text}='{textBox5.Text}', {label9.Text}={textBox6.Text} WHERE ID={Patinets1.Text}";

            }
            else if (tableName == button3.Text)
            {
                sqlExpression = $"UPDATE {tableName} SET {label4.Text}='{textBox1.Text}', {label5.Text}='{textBox2.Text}', {label6.Text}='{textBox3.Text}', {label7.Text}='{textBox4.Text}' WHERE ID={Patinets1.Text}";

            }
            else if (tableName == button4.Text)
            {
                sqlExpression = $"UPDATE {tableName} SET {label4.Text}='{textBox1.Text}', {label5.Text}={textBox2.Text} WHERE ID={Patinets1.Text}";
            }
            else if (tableName == button9.Text)
            {
                sqlExpression = $"UPDATE {tableName} SET {label4.Text}='{textBox1.Text}', {label5.Text}={textBox2.Text} WHERE ID={Patinets1.Text}";
            }

            SqlCommand command = new SqlCommand(sqlExpression, connection);
            command.ExecuteNonQuery();
        }


        private void deleteData(string tableName)
        {
            string sqlExpression = $"DELETE  FROM {tableName} WHERE ID={Patinets1.Text}";

            SqlCommand command = new SqlCommand(sqlExpression, connection);
            command.ExecuteNonQuery();
        }

        private void addData(string tableName)
        {
            string sqlExpression = "";
            if (tableName == button1.Text)
            {
                sqlExpression = $"INSERT INTO {tableName}({label3.Text}, {label4.Text}, {label5.Text}) VALUES({Patinets1.Text}, '{textBox1.Text}', {textBox2.Text})";

            }
            else if (tableName == button2.Text)
            {
                sqlExpression = $"INSERT INTO {tableName}({label3.Text}, {label4.Text}, {label5.Text}, {label6.Text}, {label7.Text}, {label8.Text}, {label9.Text}) VALUES({Patinets1.Text}, {textBox1.Text}, {textBox2.Text}, {textBox3.Text}, '{textBox4.Text}', '{textBox5.Text}', {textBox6.Text})";

            }
            else if (tableName == button3.Text)
            {
               sqlExpression = $"INSERT INTO {tableName}({label3.Text}, {label4.Text}, {label5.Text}, {label6.Text}, {label7.Text}) VALUES({Patinets1.Text}, '{textBox1.Text}', '{textBox2.Text}', '{textBox3.Text}', '{textBox4.Text}')";

            }
            else if (tableName == button4.Text)
            {
                sqlExpression = $"INSERT INTO {tableName}({label3.Text}, {label4.Text}, {label5.Text}) VALUES({Patinets1.Text}, '{textBox1.Text}', {textBox2.Text})";

            }
            else if (tableName == button9.Text)
            {
                sqlExpression = $"INSERT INTO {tableName}({label3.Text}, {label4.Text}, {label5.Text}) VALUES({Patinets1.Text}, '{textBox1.Text}', '{textBox2.Text}')";

            }


            SqlCommand command = new SqlCommand(sqlExpression, connection);
            command.ExecuteNonQuery();
        }




        private void button1_Click(object sender, EventArgs e)
        {
            tableName = button1.Text;
            getData(tableName);

            label3.Visible = true;
            Patinets1.Visible = true;
            label4.Visible = true;
            textBox1.Visible = true;
            label5.Visible = true;
            textBox2.Visible = true;
            label6.Visible = false;
            textBox3.Visible = false;
            label7.Visible = false;
            textBox4.Visible = false;
            label8.Visible = false;
            textBox5.Visible = false;
            label9.Visible = false;
            textBox6.Visible = false;

            label3.Text = dataGridView1.Columns[0].Name.ToString();
            label4.Text = dataGridView1.Columns[1].Name.ToString();
            label5.Text = dataGridView1.Columns[2].Name.ToString();


            

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (tableName == button1.Text)
            {
                Patinets1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
               
            }
            else if (tableName == button2.Text)
            {
                Patinets1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            }
            else if (tableName == button3.Text)
            {
                Patinets1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                
            }
            else if (tableName == button4.Text)
            {
                Patinets1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                
            }
            else if (tableName == button9.Text)
            {
                Patinets1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
               
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            findData(tableName, Patinets1.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            updateData(tableName);  
        }

        private void button6_Click(object sender, EventArgs e)
        {
            addData(tableName);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            deleteData(tableName);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tableName = button2.Text;
            getData(tableName);

            label3.Visible = true;
            Patinets1.Visible = true;
            label4.Visible = true;
            textBox1.Visible = true;
            label5.Visible = true;
            textBox2.Visible = true;
            label6.Visible = true;
            textBox3.Visible = true;
            label7.Visible = true;
            textBox4.Visible = true;
            label8.Visible = true;
            textBox5.Visible = true;
            label9.Visible = true;
            textBox6.Visible = true;

            label3.Text = dataGridView1.Columns[0].Name.ToString();
            label4.Text = dataGridView1.Columns[1].Name.ToString();
            label5.Text = dataGridView1.Columns[2].Name.ToString();
            label6.Text = dataGridView1.Columns[3].Name.ToString();
            label7.Text = dataGridView1.Columns[4].Name.ToString();
            label8.Text = dataGridView1.Columns[5].Name.ToString();
            label9.Text = dataGridView1.Columns[6].Name.ToString();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            tableName = button3.Text;
            getData(tableName);

            label3.Visible = true;
            Patinets1.Visible = true;

            label4.Visible = true;
            textBox1.Visible = true;

            label5.Visible = true;
            textBox2.Visible = true;

            label6.Visible = true;
            textBox3.Visible = true;

            label7.Visible = true;
            textBox4.Visible = true;

            label8.Visible = false;
            textBox5.Visible = false;

            label9.Visible = false;
            textBox6.Visible = false;

            label3.Text = dataGridView1.Columns[0].Name.ToString();
            label4.Text = dataGridView1.Columns[1].Name.ToString();
            label5.Text = dataGridView1.Columns[2].Name.ToString();
            label6.Text = dataGridView1.Columns[3].Name.ToString();
            label7.Text = dataGridView1.Columns[4].Name.ToString();
            //label8.Text = dataGridView1.Columns[5].Name.ToString();
            //label9.Text = dataGridView1.Columns[6].Name.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tableName = button4.Text;
            getData(tableName);

            label3.Visible = true;
            Patinets1.Visible = true;
            label4.Visible = true;
            textBox1.Visible = true;
            label5.Visible = true;
            textBox2.Visible = true;
            label6.Visible = false;
            textBox3.Visible = false;
            label7.Visible = false;
            textBox4.Visible = false;
            label8.Visible = false;
            textBox5.Visible = false;
            label9.Visible = false;
            textBox6.Visible = false;

            label3.Text = dataGridView1.Columns[0].Name.ToString();
            label4.Text = dataGridView1.Columns[1].Name.ToString();
            label5.Text = dataGridView1.Columns[2].Name.ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            tableName = button1.Text;
            getData(tableName);

            label3.Visible = true;
            Patinets1.Visible = true;
            label4.Visible = true;
            textBox1.Visible = true;
            label5.Visible = true;
            textBox2.Visible = true;
            label6.Visible = false;
            textBox3.Visible = false;
            label7.Visible = false;
            textBox4.Visible = false;
            label8.Visible = false;
            textBox5.Visible = false;
            label9.Visible = false;
            textBox6.Visible = false;

            label3.Text = dataGridView1.Columns[0].Name.ToString();
            label4.Text = dataGridView1.Columns[1].Name.ToString();
            label5.Text = dataGridView1.Columns[2].Name.ToString();
        }
    }
}
